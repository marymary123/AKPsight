<?php
session_start();
include("file:///wamp/www/AKPsi-Attendance/extra/body_functions.php");
include("file:///wamp/www/AKPsi-Attendance/extra/data_functions.php");

	//$connection = connect();
	//login_grab($connection);

?>