<?php

	function head_fundraising_info() {
$text = <<<TEXT
		$(document).on("click", ".item", function(e) {
            if (($(this)).hasClass("requestHelp")) {
				bootbox.alert("The position has now been made public to apply for");
			} else if (($(this)).hasClass("saveEvent")) {
				bootbox.alert("This event has been saved onto your computer!");
			}
        });
TEXT;
echo $text;
	}

	function role_info() {
$text = <<<TEXT
		$(document).on("click", ".someEvent", function(e) {
			bootbox.dialog({
				title: "[Event Name]: [Date]",
				message: '<table>' +
						 '<tr><td>[# of Members] members </td></tr>' +
						 '<tr><td> [Role name]: [Person name] &nbsp' +
						 '<button class="memberComment"> Write Comment </button></td></tr>' +
						 '<tr><td> [Role name]: [Person name] &nbsp' +
						 '<button class="memberComment"> Write Comment </button></td></tr>',
				buttons: {
                    success: {
                        label: "Ok",
                        className: "btn-success",
                    }
				}
			});
		});		
TEXT;
echo $text;
	}

	function make_event() {
$text = <<<TEXT
		$(document).on("click", ".makeEvent", function(e) {
			bootbox.dialog({
				title: "Make Event",
				message: '<table class="table">' +
						 '<tr><td>Event Name <input type="text"></input></td>' +
						 '<td>Event Date  <br><input type="text"></input></td></tr>' +
						 '<tr><td>Role 1 Name <input type="text"></input></td><td>Role 1 Description<input type="text"></input></td></tr>' +
						 '<tr><td>Role 2 Name <input type="text"></input></td><td>Role 2 Description<input type="text"></input></td></tr>' +
						 '</table>',
				buttons: {
                    success: {
                        label: "Save Event",
                        className: "btn-success item saveEvent",
                    }
				}
			});
		});		
TEXT;
echo $text;
	}

	function add_member() {
$text = <<<TEXT
		$(document).on("click", ".addMember", function(e) {
			bootbox.dialog({
				title: "Add Member",
				message: '<table class="table">' +
						 '<tr><td>Person&#39s Name <br><input type="text"></input></td>' +
						 '<td>Role Name <br><input type="text"></input></td></tr>' +
						 '</table>',
				buttons: {
                    success: {
                        label: "Save",
                        className: "btn-success",
                    }
				}
			});
		});		
TEXT;
echo $text;
	}
?>