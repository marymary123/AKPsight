<?php
	
	// Names of all the data_grab file functions
	$data_homePage1 = "Login";
	$data_homePage2 = "Profile";
	$data_homePage3 = "News";
	$data_homePage4 = "Messages";
	$data_loginValidate = "Login_Check";
	$data_committeeInfoPage1 = "Committee-Information/InvestmentInfo";
	$data_committeeMemberPage1 = "ProfessionalDevelopmentInfo";
	$data_committeeHeadPage1 = "FundraisingHead";
	$data_committeeHeadPastEventPage1 = "PhiDeltGatesPast";
	$data_committeeHeadPastPersonPage1 = "data_grab";
	
	// Important arrays with corresponding information
	return array($data_homePage1, $data_homePage2, $data_homePage3, $data_homePage4, 
	$data_loginValidate,  
	$data_committeeInfoPage1, 
	$data_committeeMemberPage1, 
	$data_committeeHeadPage1, 
	$data_committeeHeadPastEventPage1, 
	$data_committeeHeadPastPersonPage1); 
?>