<?php

	$homePage1 = "Login";
	$homePage2 = "Profile";
	$homePage3 = "News";
	$homePage4 = "Messages";
	$loginValidate = "Login_Check";
	$committeeInfoPage1 = "investmentInfo";
	$committeeMemberPage1 = "professionalDevelopmentInfo";
	$committeeHeadPage1 = "fundraisingHead";
	$committeeHeadPastEventPage1 = "phiDeltGatesPast";
	$committeeHeadPastPersonPage1 = "person1Past";

	return array($homePage1, $homePage2, $homePage3, $homePage4, 
	$loginValidate, 
	$committeeInfoPage1, 
	$committeeMemberPage1, 
	$committeeHeadPage1, 
	$committeeHeadPastEventPage1, 
	$committeeHeadPastPersonPage1); 

?>